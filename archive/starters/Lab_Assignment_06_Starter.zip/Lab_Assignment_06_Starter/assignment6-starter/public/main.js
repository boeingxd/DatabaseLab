// public/main.js
//
// Task 6 (2 pts): list and add. Task 7 (1.5 pts): delete.
// Reference the fetch()/load() pattern in Lab Sheet 06, Section 10.8 --
// same idea, just for /books instead of /students.

// TODO: grab references to your list container, form, and its inputs,
// matching whatever ids/names you used in index.html.

// TODO (Task 6): write load() -- fetch('/books'), turn the JSON response
// into HTML, and set it as your list container's innerHTML. Each row
// should show the title and price, plus a delete button carrying the
// book's id (e.g. data-id="...").

// TODO (Task 6): on the form's submit event, prevent the default reload,
// POST the form values as JSON to /books, then call load() again.
// If the response isn't ok, show the server's error message to the user.

// TODO (Task 7): listen for clicks on the list container; when a delete
// button is clicked, send a DELETE request to /books/<that button's id>,
// then call load() again.

// TODO: call load() once at the bottom so the list appears on page load.
